import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';

import axios from 'axios';


function App() {
  // const initialvalues ={Username:"", email:"", Password:""};
  // const [formvalues, setformvalues] =usestate(initialvalues);

  const [email, setEmail] = useState("")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")

  const handleSubmt =(e)=>{
    e.preventDefault();

    axios.post("http://localhost:9000/users",{email,username,password}).then((res)=>{
      localStorage.setItem("token", JSON.stringify(res))

    }).catch((err)=>{
      console.warn(err)
    })

  }
  return (
    <div className="App">
      <form>
        <h1>Login Form</h1>
        <div className='ui divider'></div>
        <div className='ui form'>
          <div className="field">
            <label>UserName</label>
            <input
              type="text"
              name="UserName"
              placeholder="UserName"
              value={username}
              onChange={(e)=>setUsername(e.target.value)}

            >
            </input>
          </div>
          <div className="field">
            <label>Email</label>
            <input
              type="email"
              name="email"
              placeholder="Email"
              value={email}
              onChange={($event)=>setEmail($event.target.value)}
            >
            </input>
          </div>
          <div className="field">
            <label>Password</label>
            <input
              type="Password"
              name="Password"
              placeholder="Password"
              value={password}
              onChange={(e)=>setPassword(e.target.value)}

            >
            </input>
          </div>
          <button className="fluid ui button blue" onClick={handleSubmt}>Submit</button>
        </div>
      </form>
    </div>
  );
}

export default App;
